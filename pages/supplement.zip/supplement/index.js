import { RiArrowDropDownFill } from "react-icons/ri";
import { useState, useRef, useEffect, router } from "react";
import { TiWeatherSunny } from "react-icons/ti";
import { BiShieldAlt2, BiUser } from "react-icons/bi";
import { TbHeartRateMonitor } from "react-icons/tb";
import { GiBoatPropeller } from "react-icons/gi";
import { FaHome } from "react-icons/fa";
import { BsMoonStarsFill } from "react-icons/bs";
import { useTheme } from "next-themes";
import AddModule from "./moduleDetail/moduleSection";
import AddSection from "./projectDetail/projectSection";
import Image from "next/image";
import AddPage from "./pageDetail/pageSection";
import ProjectDtl from "./projectDetail";

const Add = () => {
  const { systemTheme, theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [active, setActive] = useState("general");

  useEffect(() => {
    setMounted(true);
  }, []);
  const renderThemeChanger = () => {
    if (!mounted) return null;

    const currentTheme = theme === "system" ? systemTheme : theme;

    if (currentTheme === "dark") {
      return (
        <BsMoonStarsFill
          className="w-5 h-5 text-blue-400 "
          role="button"
          onClick={() => setTheme("light")}
        />
      );
    } else {
      return (
        <TiWeatherSunny
          className="w-6 h-6 text-slate-500 hover:text-dark"
          role="button"
          onClick={() => setTheme("dark")}
        />
      );
    }
  };
  return (
    <div className="flex dark:bg-slate-800">
      <div className="w-1/3 flex">
        <aside
          className="w-60 left-0 relative 
      "
          aria-label="Sidebar"
        >
          <div className="overflow-y-auto py-6 px-5 bg-white border-r-0 h-screen rounded dark:bg-slate-900">
            <ul className="space-y-2 dark:text-slate-200">
              <li className="px-3">
                <div className="flex flex-row items-center h-8">
                  <div className="text-sm font-light tracking-wide text-gray-500 dark:text-slate-400">
                    Menu
                  </div>
                </div>
              </li>
              <li>
                <a
                  href="/"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <FaHome className="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400   dark:group-hover:text-white group-hover:text-gray-900" />
                  <span className="ml-3">Нүүр</span>
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
                    <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
                  </svg>
                  <span className="ml-3">Хэрэгсэл</span>
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  {renderThemeChanger()}
                  <span className="ml-3 dark:ml-4 mr-3">DarkMode</span>
                </a>
              </li>
              <li>
                <button
                  type="button"
                  className="flex items-center p-2 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
                  aria-controls="dropdown-example"
                  data-collapse-toggle="dropdown-example"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                  <span
                    className="flex-1 ml-3 text-left whitespace-nowrap"
                    sidebar-toggle-item
                  >
                    Баримт бичиг
                  </span>
                  <svg
                    sidebar-toggle-item
                    className="w-6 h-6"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                </button>
                <ul id="dropdown-example" className="hidden py-2 space-y-2">
                  <li>
                    <a
                      href="#"
                      className="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
                    >
                      Бүтээгдэхүүн
                    </a>
                  </li>
                  <li>
                    <a
                      href="#"
                      className="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
                    >
                      Billing
                    </a>
                  </li>

                  <li>
                    <a
                      href="#"
                      className="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700"
                    >
                      Invoice
                    </a>
                  </li>
                </ul>
              </li>
              <li className="px-3">
                <div className="flex flex-row items-center h-8">
                  <div className="text-sm font-light tracking-wide text-gray-500 dark:text-slate-400">
                    Other
                  </div>
                </div>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                  </svg>
                  <span className="flex-1 ml-3 whitespace-nowrap">
                    Өөрчлөлт
                  </span>
                  <span className="inline-flex justify-center items-center px-2 ml-3 text-sm font-medium text-gray-800 bg-gray-200 rounded-full dark:bg-gray-700 dark:text-gray-300">
                    Pro
                  </span>
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M8.707 7.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l2-2a1 1 0 00-1.414-1.414L11 7.586V3a1 1 0 10-2 0v4.586l-.293-.293z"></path>
                    <path d="M3 5a2 2 0 012-2h1a1 1 0 010 2H5v7h2l1 2h4l1-2h2V5h-1a1 1 0 110-2h1a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V5z"></path>
                  </svg>
                  <span className="flex-1 ml-3 whitespace-nowrap">Хүсэлт</span>
                  <span className="inline-flex justify-center items-center p-3 ml-3 w-3 h-3 text-sm font-medium text-blue-600 bg-blue-200 rounded-full dark:bg-blue-900 dark:text-blue-200">
                    3
                  </span>
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                  <span className="flex-1 ml-3 whitespace-nowrap">
                    Тохиргоо
                  </span>
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                  <span className="flex-1 ml-3 whitespace-nowrap">
                    Бүтээгдэхүүн
                  </span>
                </a>
              </li>
              <li className="px-3">
                <div className="flex flex-row items-center h-8">
                  <div className="text-sm font-light tracking-wide text-gray-500 dark:text-slate-400">
                    Нэвтрэлт
                  </div>
                </div>
              </li>
              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                  <span className="flex-1 ml-3 whitespace-nowrap">
                    Нэвтрэх тохиргоо
                  </span>
                </a>
              </li>

              <li>
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <svg
                    aria-hidden="true"
                    className="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      d="M5 4a3 3 0 00-3 3v6a3 3 0 003 3h10a3 3 0 003-3V7a3 3 0 00-3-3H5zm-1 9v-1h5v2H5a1 1 0 01-1-1zm7 1h4a1 1 0 001-1v-1h-5v2zm0-4h5V8h-5v2zM9 8H4v2h5V8z"
                      clipRule="evenodd"
                    ></path>
                  </svg>
                  <span className="flex-1 ml-3 whitespace-nowrap group-focus:text-white ">
                    Гарах
                  </span>
                </a>
              </li>
            </ul>
          </div>
          <div className="relative flex items-center justify-center flex-shrink-0 px-2 py-4 space-x-4 border-r-2 bg-white">
            <button
              className="p-2 transition-colors duration-200 rounded-full text-primary-lighter bg-primary-50 hover:text-primary hover:bg-primary-100 dark:hover:text-light dark:hover:bg-primary-dark dark:bg-dark focus:outline-none focus:bg-primary-100 dark:focus:bg-primary-dark focus:ring-primary-darker"
              fdprocessedid="mh7rk6"
            >
              <span className="sr-only">Search panel</span>
              <svg
                className="w-7 h-7"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                ></path>
              </svg>
            </button>
            <div>
              <button
                type="button"
                aria-haspopup="true"
                className="block transition-opacity duration-200 rounded-full dark:opacity-75 dark:hover:opacity-100 focus:outline-none focus:ring dark:focus:opacity-100"
                aria-expanded="false"
                fdprocessedid="5vl8b8"
              >
                <span className="sr-only">User menu</span>
                <Image
                  height={10}
                  width={10}
                  className="w-10 h-10 rounded-full"
                  src="/../public/favicon.ico"
                  alt="Something happening"
                />
              </button>
              <div
                className="absolute max-w-xs py-1 bg-white rounded-md shadow-lg min-w-max left-5 right-5 bottom-full ring-1 ring-black ring-opacity-5 dark:bg-dark focus:outline-none hidden"
                tabIndex="-1"
                role="menu"
                aria-orientation="vertical"
                aria-label="User menu"
              >
                <a
                  href="#"
                  role="menuitem"
                  className="block px-4 py-2 text-sm text-gray-700 transition-colors hover:bg-gray-100 dark:text-light dark:hover:bg-primary"
                >
                  Your Profile
                </a>
                <a
                  href="#"
                  role="menuitem"
                  className="block px-4 py-2 text-sm text-gray-700 transition-colors hover:bg-gray-100 dark:text-light dark:hover:bg-primary"
                >
                  Settings
                </a>
                <a
                  href="#"
                  role="menuitem"
                  className="block px-4 py-2 text-sm text-gray-700 transition-colors hover:bg-gray-100 dark:text-light dark:hover:bg-primary"
                >
                  Logout
                </a>
              </div>
            </div>
            <button
              className="p-2 transition-colors duration-200 rounded-full text-primary-lighter bg-primary-50 hover:text-primary hover:bg-primary-100 dark:hover:text-light dark:hover:bg-primary-dark dark:bg-dark focus:outline-none focus:bg-primary-100 dark:focus:bg-primary-dark focus:ring-primary-darker"
              fdprocessedid="fgzult"
            >
              <span className="sr-only">Open settings panel</span>
              <svg
                className="w-7 h-7"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                ></path>
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                ></path>
              </svg>
            </button>
          </div>
        </aside>
        <aside
          className="w-60 h-screen bg-slate-100 border-r-2  dark:bg-slate-800 dark:border-r-2"
          aria-label="Sidebar"
        >
          <div className="flex-shrink-0 ">
            <div className="px-4 pt-4 border-b dark:border-primary-darker">
              <h2
                id="secondSidebarHeader"
                className="pb-4 font-semibold px-4 text-gray-900"
              >
                Нэмэлт хэсэг
              </h2>
            </div>
          </div>
          <div className="overflow-y-auto pb-6   h-screen rounded dark:bg-gray-800 pt-5 ">
            <ul className="space-y-2 text-gray-500 list-none justify-center items-center">
              <li className="px-3 list-none ">
                <div className="flex flex-row items-center h-8">
                  <div className="text-sm font-medium tracking-wide text-gray-500 pl-4 ">
                    Нэмэлтийн төрөл
                  </div>
                  <RiArrowDropDownFill className="ml-2 w-6 h-6 text-gray-500" />
                </div>
              </li>
              <li className="pl-7">
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900    dark:hover:bg-gray-700 rounded-sm transition duration-75 group dark:hover:border-r-4 dark:hover:border-sky-400   hover:border-r-4 hover:border-sky-400 focus:border-r-4 focus:border-sky-400 dark:focus:bg-slate-800 focus:bg-slate-200"
                  onClick={() => {
                    setActive("AddSection");
                  }}
                  onChange={() => []}
                >
                  <span className="text-slate-600 hover:text-black dark:hover:text-slate-150  dark:hover:text-white dark:text-slate-300 focus:text-dark group-focus:border ">
                    Төсөл
                  </span>
                </a>
              </li>
              <li className="pl-7">
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900    dark:hover:bg-gray-700 rounded-sm transition duration-75 group dark:hover:border-r-4 dark:hover:border-sky-400   hover:border-r-4 hover:border-sky-400 focus:border-r-4 focus:border-sky-400 dark:focus:bg-slate-800 "
                  onClick={() => {
                    setActive("AddModule");
                  }}
                >
                  <span className="text-slate-600 hover:text-black dark:hover:text-white dark:text-slate-300 dark:focus:bg-slate-800">
                    Модул
                  </span>
                </a>
              </li>
              <li className="pl-7">
                <a
                  href="#"
                  className="flex items-center p-2 text-base font-normal text-gray-900 rounded-sm   hover:border-r-4 hover:border-sky-400 dark:hover:bg-gray-700 dark:hover:border-r-4 dark:hover:border-sky-400 focus:border-r-4 focus:border-sky-400 focus:bg-slate-200"
                  onClick={() => {
                    setActive("TestMD");
                  }}
                >
                  <span className="flex-1  whitespace-nowrap dark:hover:text-slate-150 dark:hover:text-white dark:text-slate-300 ">
                    Контент
                  </span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
      </div>
      <div className=" pt-10  w-2/3 flex dark:bg-slate-800">
        {active === "general" && (
          <div>
            <div className="ml-10  lg:mx-10 xl:mr-80">
              <section class="text-gray-600 body-font">
                <div class="container px-5 py-24 mx-auto flex flex-wrap flex-col">
                  <div class="flex mx-auto flex-wrap mb-20">
                    <a class="sm:px-6 py-3 w-1/2 sm:w-auto justify-center sm:justify-start border-b-2 title-font font-medium bg-gray-100 inline-flex items-center leading-none border-indigo-500 text-indigo-500 tracking-wider rounded-t">
                      <BiUser className="mr-3 h-5 w-5" />
                      Алхам 1
                    </a>
                    <a class="sm:px-6 py-3 w-1/2 sm:w-auto justify-center sm:justify-start border-b-2 title-font font-medium inline-flex items-center leading-none border-gray-200 hover:text-gray-900  hover:bg-gray-100 tracking-wider  focus:bg-slate-300 cursor-default">
                      <BiShieldAlt2 className="mr-3 h-5 w-5" />
                      Алхам 2
                    </a>
                    <a class="sm:px-6 py-3 w-1/2 sm:w-auto justify-center sm:justify-start border-b-2 title-font font-medium inline-flex items-center leading-none border-gray-200 hover:text-gray-900 tracking-wider hover:bg-gray-100 focus:bg-slate-300 cursor-default">
                      <TbHeartRateMonitor className="mr-3 h-5 w-5" />
                      Алхам 3
                    </a>
                    <a class="sm:px-6 py-3 w-1/2 sm:w-auto justify-center sm:justify-start border-b-2 title-font font-medium inline-flex items-center leading-none border-gray-200 hover:text-gray-900 tracking-wider hover:bg-gray-100 focus:bg-slate-300 cursor-default">
                      <GiBoatPropeller className="mr-3 h-5 w-5" />
                      Алхам 4
                    </a>
                  </div>
                  <img
                    className="xl:w-1/4 lg:w-400px lg:h-auto md:w-1/2 block mx-auto mb-10 object-cover object-center rounded w-96"
                    alt="hero"
                    src="./fog.jpg"
                  />
                  <div class="flex flex-col text-center w-full">
                    <h1 class="text-xl font-medium title-font mb-4 text-gray-900">
                      Төсөл, модул, Контент бүртгэл
                    </h1>
                    <p class="lg:w-2/3 mx-auto leading-relaxed text-base">
                      Whatever cardigan tote bag tumblr hexagon brooklyn
                      asymmetrical gentrify, subway tile poke farm-to-table.
                      Franzen you probably haven't heard of them man bun deep
                      jianbing selfies heirloom prism food truck ugh squid
                      celiac humblebrag.
                    </p>
                  </div>
                </div>
              </section>
            </div>
          </div>
        )}
        {active === "AddModule" && <AddModule />}
        {active === "TestMD" && <AddPage />}
        {active === "AddSection" && <ProjectDtl />}
      </div>
    </div>
  );
};

export default Add;
