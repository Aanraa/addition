import { useEffect, useState } from "react";
import axios from "axios";
//import CustomCKEditor from "../../../components/CustomCKEditor";
import Link from "next/link";
import { RiArrowDropDownLine } from "react-icons/ri";
import dynamic from "next/dynamic";

const CustomCKEditor = dynamic(
  () => import("../../../../components/CustomCKEditor"),
  {
    ssr: false,
  }
);

export default function AddPage() {
  const [editorLoaded, setEditorLoaded] = useState(false);
  const [data, setData] = useState("");
  const [desc, setDesc] = useState("");
  const [mdKey, setMdKey] = useState([]);
  const [itemId, setItemId] = useState("");
  const [loading, setLoading] = useState(false);
  const [projName, setProjName] = useState([]);

  const selectModId = (item) => {
    setItemId(item);
    console.log("yu wee>>>>", itemId);
  };

  const selectProjId = (item) => {
    console.log("prjId-g avav>>>>", item);
    axios
      .post("/api/post/pages/getModKey", { projectKey: item })
      .then((res) => {
        console.log(res.data, "getmodKey");
        setMdKey(res.data);
      })
      .catch((err) => console.log(err));
    console.log(mdKey, "this is real data>>>>>>>");
  };

  useEffect(() => {
    setEditorLoaded(true);
    getProjNames();
  }, []);

  const getProjNames = () => {
    axios
      .get("/api/get/module/getProjectName")
      .then((res) => {
        setProjName(res.data);
        console.log("proj name>>>>>>>", res.data);
      })
      .catch((err) => console.log(err));
  };

  const handleSubmit = async (event) => {
    const PAGE_API_URL = "/api/post/pages/savePage";
    event.preventDefault();

    const pjKey = mdKey.filter((el) => {
      if (el.pKey === itemId) return el.projectKey;
    });

    console.log("pj bnn", pjKey);

    // Get data from the form.
    const data = {
      name: event.target.cName.value,
      id: event.target.cCode.value,
      moduleKey: itemId,
      description: desc,
      projectKey: pjKey[0].projectKey,
    };
    const config = {
      headers: {
        "Content-Type": "application/json",
        accept: "application/json",
      },
    };
    setLoading(true);
    axios
      .post(PAGE_API_URL, data, config)
      .then((res) => {
        setLoading(false);
        console.log("datasdfasdfdsaa bn", res.data);

        if (res.data === "amjilttai") {
          alert("Амжилттай хадгаллаа");
          document.getElementById("create-course-form").reset();
          CKEDITOR.instances.editor1.setData("your text or html code");
        } else {
          alert(`Алдаа гарлаа, ${res.data}`);
        }
      })
      .catch((err) => console.log(err));
    setLoading(false);
  };

  return (
    <section className="text-gray-600 body-font relative ">
      <div className="container px-5 mx-auto mt-20 max-w-3xl mb-20">
        <form method="POST" onSubmit={handleSubmit} id="create-course-form">
          <div className="flex justify-between items-center">
            <div className="text-center w-full flex justify-between items-center sm:items-start  flex-col sm:flex-row ">
              <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2 text-gray-900">
                Контент нэмэх
              </h1>
              <div className="flex justify-center  mb-5 sm:mb-12  gap-2 mt-5 sm:mt-0 max-w-xs sm:w-auto">
                <button
                  className="flex mx-auto text-white bg-indigo-400 border-0 py-2 px-8 hover:bg-indigo-600 rounded text-lg "
                  type="submit"
                  disabled={loading}
                >
                  Хадгалах
                </button>
                <Link href="/">
                  <button
                    className="flex mx-auto text-white bg-gray-300 border-0 py-2 px-8 focus:outline-none hover:bg-red-600 rounded text-lg"
                    type="button"
                  >
                    Болих
                  </button>
                </Link>
              </div>
            </div>
          </div>
          <div className=" mx-auto">
            <div className="flex flex-wrap -m-2 mb-4">
              <div className="p-2 w-1/2">
                <div className="relative">
                  <label
                    htmlFor="mCode"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                  >
                    Төслийн нэр
                  </label>

                  <select
                    id="default"
                    defaultValue={1}
                    className=" bg-gray-50 border  text-gray-900 text-sm rounded-lg hover:border-sky-300 focus:ring-blue-500 focus:border-blue-400 block w-40 py-2 dark:hover:border-blue-400 dark:bg-slate-900 dark:border-slate-900 dark:placeholder-gray-400 dark:text-white dark:focus:text-white dark:focus:border-blue-500 ring-slate-200 border-solid border-white dark:"
                    onChange={(e) => {
                      selectProjId(e.target.value);
                    }}
                  >
                    <option value={""}>Сонгоно уу</option>
                    {projName.map(
                      (val) => (
                        console.log("iddddd>>>>", val),
                        (
                          <option
                            key={val.pKey}
                            value={val.pKey}
                            className="text-slate-900"
                            // onChange={() => console.log("first", val)}
                          >
                            {val.name}
                          </option>
                        )
                      )
                    )}
                  </select>
                </div>
              </div>
              <div className="p-2 w-1/2">
                <div className="relative">
                  <label
                    htmlFor="mCode"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                  >
                    Модулын нэр
                  </label>

                  <select
                    id="default"
                    defaultValue={1}
                    className=" bg-gray-50 border  text-gray-900 text-sm rounded-lg hover:border-sky-300 focus:ring-blue-500 focus:border-blue-400 block w-40 py-2 dark:hover:border-blue-400 dark:bg-slate-900 dark:border-slate-900 dark:placeholder-gray-400 dark:text-white dark:focus:text-white dark:focus:border-blue-500 ring-slate-200 border-solid border-white dark:"
                    onChange={(e) => {
                      selectModId(e.target.value);
                    }}
                  >
                    <option value={""}>Сонгоно уу</option>
                    {mdKey.map((val) => (
                      // console.log("iddddd>>>>", val),
                      <option
                        key={val.pKey}
                        value={val.pKey}
                        className="text-slate-900"
                        // onChange={() => console.log("first", val)}
                      >
                        {val.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap -m-2">
              <div className="p-2 w-1/2">
                <div className="relative">
                  <label
                    htmlFor="cName"
                    className=" flex mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                  >
                    Контентийн нэр
                  </label>
                  <input
                    type="text"
                    id="cName"
                    name="cName"
                    placeholder="Vendor... гэх мэт"
                    required
                    className="w-full bg-gray-100 dark:bg-white bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                  />
                </div>
              </div>
              <div className="p-2 w-1/2">
                <div className="relative">
                  <label
                    htmlFor="pCode"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                  >
                    Контентийн код
                  </label>
                  <input
                    type=""
                    id="cCode"
                    name="cCode"
                    placeholder="105536987456"
                    required
                    maxLength={20}
                    className="w-full bg-gray-100 bg-opacity-50 dark:bg-white rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                  />
                </div>
              </div>

              <div className="flex-row items-center justify-center ">
                <h1 className="py-4 pl-2 font-medium text-sm text-start">
                  Page тайлбар
                </h1>
                <div className="dark:text-black pl-2 h-44 w-max " id="cDesc">
                  <CustomCKEditor
                    name="description"
                    onChange={(data) => {
                      setData(data);
                      setDesc(data);
                    }}
                    class="cDesc"
                    editorLoaded={editorLoaded}
                  />
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </section>
  );
}
