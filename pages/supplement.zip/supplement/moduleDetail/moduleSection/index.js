import axios from "axios";
import Link from "next/link";
import { cache, use, useEffect, useRef, useState } from "react";
import { icons } from "react-icons";
import { RiArrowDropDownLine } from "react-icons/ri";

const AddModule = () => {
  const [image, setImage] = useState(false);
  const [openProj, setProj] = useState(false);
  const [projName, setProjName] = useState([]);
  const [itemId, setItemId] = useState("");
  const [loading, setLoading] = useState(false);

  const godMenu = useRef(null);

  const selectProjId = (item) => {
    setItemId(item);
    console.log("yu wee>>>>", item);
  };

  useEffect(() => {
    getProjNames();
  }, []);

  const getProjNames = () => {
    axios
      .get("/api/get/module/getProjectName")
      .then((res) => {
        setProjName(res.data);
        console.log("proj name>>>>>>>", projName);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    const closeOpenMenu = (e) => {
      if (godMenu.current && openProj && !godMenu.current.contains(e.target)) {
        setProj(false);
      }
    };
    document.addEventListener("mousedown", closeOpenMenu);
  });

  // function handleKeyDown(e) {
  //   if (e.key === "Escape" && openVer) {
  //     e.stopPropagation();
  //   }
  // }

  const handleSubmit = async (event) => {
    const MOD_API_URL = "/api/post/module/saveModule";
    event.preventDefault();

    const data = {
      name: event.target.mName.value,
      id: event.target.mCode.value,
      projectKey: itemId,
    };
    const config = {
      headers: {
        "Content-Type": "application/json",
        accept: "application/json",
      },
    };
    setLoading(true);
    axios
      .post(MOD_API_URL, data, config)
      .then((res) => {
        setLoading(false);
        console.log("data bn", res.data);
        if (res.data === "amjilttai") {
          alert("Амжилттай хадгаллаа");
          document.getElementById("create-course-form").reset();
        } else {
          alert(`Алдаа гарлаа, ${res.data}`);
        }
      })
      .catch((err) => console.log(err));
    setLoading(false);
  };

  return (
    <div className="">
      <section className="text-gray-600 body-font relative">
        <div className="container px-5 mt-20 max-w-3xl mx-auto">
          <form
            method="POST"
            className=""
            onSubmit={handleSubmit}
            id="create-course-form"
          >
            <div className="flex justify-between items-center">
              <div className=" text-center w-full mb-12  flex justify-between items-center sm:items-start  flex-col sm:flex-row">
                <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2 text-gray-900">
                  Модул нэмэх
                </h1>
                <div className=" flex justify-center  mb-5 sm:mb-12  gap-2 mt-5 sm:mt-0 max-w-xs sm:w-auto">
                  <button
                    className="flex mx-auto text-white bg-indigo-400 border-0 py-2 px-8 hover:bg-indigo-600 rounded text-lg "
                    type="submit"
                    disabled={loading}
                  >
                    Хадгалах
                  </button>
                  <Link href="/">
                    <button
                      className="flex mx-auto text-white bg-gray-300 border-0 py-2 px-8 focus:outline-none hover:bg-red-600 rounded text-lg"
                      type="button"
                    >
                      Болих
                    </button>
                  </Link>
                </div>
              </div>
            </div>

            <div className="  mx-auto">
              <div className=" w-1/2">
                <div className="relative">
                  <label
                    htmlFor="mCode"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                  >
                    Төслийн нэр
                  </label>

                  <select
                    id="default"
                    defaultValue={1}
                    className=" bg-gray-50 border  text-gray-900 text-sm rounded-lg hover:border-sky-300 focus:ring-blue-500 focus:border-blue-400 block w-40 py-2 dark:hover:border-blue-400 dark:bg-slate-900 dark:border-slate-900 dark:placeholder-gray-400 dark:text-white dark:focus:text-white dark:focus:border-blue-500 ring-slate-200 border-solid border-white z-40 mb-4"
                    onChange={(e) => selectProjId(e.target.value)}
                  >
                    <option value={""}>Төсөл</option>
                    {projName.map((val) => (
                      <option
                        key={val.pKey}
                        value={val.pKey}
                        className="text-black"
                      >
                        {val.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex flex-wrap -m-2">
                <div className="p-2  w-1/2">
                  <div className="relative">
                    <label
                      htmlFor="mName"
                      className=" block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                    >
                      Модулын нэр
                    </label>
                    <input
                      type="text"
                      id="mName"
                      name="mName"
                      required
                      min={1}
                      placeholder="Жишээ нь : Худалдан авалт"
                      className="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                    />
                  </div>
                </div>
                <div className="p-2 w-1/2">
                  <div className="relative">
                    <label
                      htmlFor="mCode"
                      className="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7"
                    >
                      Модулын код
                    </label>
                    <input
                      type="int"
                      id="mCode"
                      name="mCode"
                      required
                      max={5}
                      min={3}
                      placeholder="001"
                      className="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                    />
                  </div>
                </div>
                <div className="p-2 w-full">
                  <div className="relative">
                    <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300 leading-7">
                      Зураг
                    </label>
                    <div className="flex justify-center items-center w-full">
                      <label
                        htmlFor="dropic"
                        className="flex flex-col justify-center items-center w-full h-64 bg-gray-50 rounded-lg border-2 border-gray-300 border-dashed cursor-pointer dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                      >
                        <div className="flex flex-col justify-center items-center pt-5 pb-6">
                          <svg
                            aria-hidden="true"
                            className="mb-3 w-10 h-10 text-gray-400"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                            ></path>
                          </svg>
                          <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                            <span className="font-semibold">
                              Энд дарж зураг оруулна
                            </span>{" "}
                            эсвэл чирж авчирна уу
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            SVG, PNG, JPG эсвэл GIF (MAX. 800x400px)
                          </p>
                          <span
                            id="test2"
                            name="test2"
                            className="mt-2 text-xs text-gray-500 dark:text-gray-400 font-semibold"
                          >
                            Filename
                          </span>
                        </div>
                        <input
                          id="dropic"
                          name="dropic"
                          type="file"
                          accept="image/*"
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </section>
    </div>
  );
};
export default AddModule;
