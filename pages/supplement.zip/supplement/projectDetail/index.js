import axios from "axios";
import { useEffect, useState } from "react";
import { AiOutlineSearch } from "react-icons/ai";
import {
  MdCheckBoxOutlineBlank,
  MdCheckBox,
  MdEdit,
  MdDelete,
} from "react-icons/md";

const ProjectDtl = () => {
  const [dtl, setDtl] = useState([]);

  useEffect(() => {
    getProjNames();
  }, []);

  const getProjNames = () => {
    axios
      .get("/api/get/module/getProjectName")
      .then((res) => {
        setDtl(res.data);
        console.log("proj name>>>>>>>", dtl);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      <div className="container px-5 mx-auto my-20 max-w-5xl font-sans">
        <form className="mb-10 w-96">
          <label
            for="default-search"
            className="mb-10 text-sm font-medium text-gray-900 sr-only dark:text-white"
          >
            Search
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <AiOutlineSearch className="w-5 h-5 text-gray-500 dark:text-gray-400" />
            </div>
            <input
              type="search"
              id="default-search"
              className="block w-full p-4 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              placeholder="Search Mockups, Logos..."
              required
            />
            <button
              type="submit"
              className="text-white absolute right-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            >
              Search
            </button>
          </div>
        </form>
        <div className="flex justify-center items-center">
          <table className=" hover:table-fixed table-fixed  max-w-xl w-fit">
            <thead>
              <tr className="rounded-md ">
                <th className="bg-blue-100 border text-left w-24 px-8 py-4">
                  <MdCheckBoxOutlineBlank className="w-5 h-5 items-center" />
                </th>
                <th className="bg-blue-100 border text-left px-8 py-4 w-44 items-center">
                  Төслийн нэр
                </th>
                <th className="bg-blue-100 border text-left px-8 py-4 w-56">
                  Төслийн ID
                </th>
                <th className="bg-blue-100 border text-left px-8 py-4 w-96">
                  Тайлбар
                </th>
                <th className="bg-blue-100 border text-left px-8 py-4 w-40">
                  Үйлдэл
                </th>
              </tr>
            </thead>
            <tbody>
              {dtl?.map((el, key) => (
                <tr>
                  <td className="px-8 py-4" key={key}>
                    <MdCheckBoxOutlineBlank
                      className="w-5 h-5 items-center"
                      onClick={() => {}}
                    />
                  </td>
                  <td className="px-8 py-4" key={key}>
                    {el?.name || ""}
                  </td>
                  <td className="px-8 py-4" key={key}>
                    {el?.pKey || ""}
                  </td>
                  <td
                    className="px-8 py-4 overflow-hidden truncate w-32"
                    key={key}
                  >
                    <p className="truncate text-ellipsis hover:text-clip overflow-hidden">
                      {" "}
                      {el?.description || ""}
                    </p>
                  </td>
                  <td className="px-8 py-4 flex text-slate-400" key={key}>
                    <MdEdit className="w-5 h-5 hover:text-black" />
                    <MdDelete className="w-5 h-5 ml-4 hover:text-black" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProjectDtl;
